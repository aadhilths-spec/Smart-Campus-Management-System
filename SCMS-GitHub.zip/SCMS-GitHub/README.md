# Smart Campus Management System (SCMS)
## CMP 7001 – Advanced Programming | Cardiff Metropolitan University

A Java-based prototype for managing room bookings, maintenance requests, and campus notifications.

---

## Features
- Room Management (add, edit, deactivate, activate)
- Booking System (with double-booking prevention)
- Maintenance Request Tracking (Pending → Assigned → Completed)
- Notification System using Observer pattern
- Three user roles: Admin, Staff, Student
- Console-based menu application

---

## Design Patterns Used
| Pattern | Type | Class |
|---------|------|-------|
| Factory Method | Creational | RoomFactory.java |
| Singleton | Creational | NotificationService.java |
| Facade | Structural | SCMSFacade.java |
| Observer | Behavioural | Observer.java / NotificationService.java |

---

## Project Structure
```
src/scms/
├── SCMSApp.java              ← Main entry point
├── model/                    ← Core entity classes
│   ├── User.java (abstract)
│   ├── Admin.java
│   ├── StaffMember.java
│   ├── Student.java
│   ├── Room.java
│   ├── Booking.java
│   ├── MaintenanceRequest.java
│   └── (enums: UserRole, RoomType, BookingStatus, etc.)
├── exception/                ← Custom exceptions
│   ├── BookingConflictException.java
│   ├── RoomNotFoundException.java
│   ├── UnauthorisedActionException.java
│   └── DuplicateEntryException.java
├── pattern/                  ← Design pattern classes
│   ├── Observer.java
│   ├── Observable.java
│   ├── RoomFactory.java
│   └── SCMSFacade.java
├── service/                  ← Business logic
│   ├── BookingManager.java
│   ├── RoomManager.java
│   ├── MaintenanceService.java
│   ├── UserManager.java
│   └── NotificationService.java
└── test/                     ← JUnit 4 tests
    ├── BookingManagerTest.java
    ├── MaintenanceServiceTest.java
    └── NotificationServiceTest.java
```

---

## How to Run
1. Open NetBeans IDE
2. Open the SCMS project
3. Right-click `SCMSApp.java` → Run File
4. Login with sample credentials below

### Sample Login Credentials
| Role | User ID | Password |
|------|---------|----------|
| Admin | U001 | admin123 |
| Staff | U002 | staff123 |
| Student | U004 | stud123 |

---

## Unit Tests
Requires JUnit 4.13.2 and Hamcrest 1.3 libraries.

Right-click any test file → Test File

| Test Class | Tests | Result |
|-----------|-------|--------|
| BookingManagerTest | 11 | All pass |
| MaintenanceServiceTest | 7 | All pass |
| NotificationServiceTest | 5 | All pass |

---

## Technologies
- Java 22
- NetBeans IDE 21
- JUnit 4.13.2
- Hamcrest 1.3
