package scms.model;

public class Student extends User {

    private String programme;

    public Student(String userId, String name, String email, String password, String programme) {
        super(userId, name, email, password, UserRole.STUDENT);
        this.programme = programme;
    }

    public String getProgramme() { return programme; }

    @Override
    public String getDashboardInfo() {
        return "Student Dashboard [" + programme + "]: View rooms, request bookings, view announcements.";
    }
}
