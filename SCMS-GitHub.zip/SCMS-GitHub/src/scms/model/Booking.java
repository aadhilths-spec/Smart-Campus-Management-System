package scms.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Booking {
    private String bookingId;
    private String roomId;
    private String userId;
    private LocalDate date;
    private LocalTime startTime;
    private LocalTime endTime;
    private BookingStatus status;

    public Booking(String bookingId, String roomId, String userId,
                   LocalDate date, LocalTime startTime, LocalTime endTime) {
        this.bookingId = bookingId;
        this.roomId = roomId;
        this.userId = userId;
        this.date = date;
        this.startTime = startTime;
        this.endTime = endTime;
        this.status = BookingStatus.CONFIRMED;
    }

    public String getBookingId()    { return bookingId; }
    public String getRoomId()       { return roomId; }
    public String getUserId()       { return userId; }
    public LocalDate getDate()      { return date; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime()   { return endTime; }
    public BookingStatus getStatus() { return status; }

    public void setStatus(BookingStatus status) { this.status = status; }

    public boolean overlapsWith(LocalDate otherDate, LocalTime otherStart, LocalTime otherEnd) {
        if (!this.date.equals(otherDate)) return false;
        if (this.status == BookingStatus.CANCELLED) return false;
        return this.startTime.isBefore(otherEnd) && this.endTime.isAfter(otherStart);
    }

    @Override
    public String toString() {
        return String.format("Booking[%s] Room: %s | User: %s | %s %s-%s | %s",
                bookingId, roomId, userId, date, startTime, endTime, status);
    }
}
