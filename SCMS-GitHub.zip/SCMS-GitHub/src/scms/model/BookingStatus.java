package scms.model;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    PENDING
}
