package scms.model;

public class StaffMember extends User {

    private String department;

    public StaffMember(String userId, String name, String email, String password, String department) {
        super(userId, name, email, password, UserRole.STAFF);
        this.department = department;
    }

    public String getDepartment() { return department; }

    @Override
    public String getDashboardInfo() {
        return "Staff Dashboard [" + department + "]: Book rooms, submit maintenance, view notifications.";
    }
}
