package scms.model;

public abstract class User {
    private String userId;
    private String name;
    private String email;
    private String password;
    private UserRole role;

    public User(String userId, String name, String email, String password, UserRole role) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.password = password;
        this.role = role;
    }

    public String getUserId()   { return userId; }
    public String getName()     { return name; }
    public String getEmail()    { return email; }
    public String getPassword() { return password; }
    public UserRole getRole()   { return role; }

    public abstract String getDashboardInfo();

    @Override
    public String toString() {
        return "[" + role + "] " + name + " (ID: " + userId + ")";
    }
}
