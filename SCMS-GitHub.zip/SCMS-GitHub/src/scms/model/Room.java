package scms.model;

import java.util.List;
import java.util.ArrayList;

public class Room {
    private String roomId;
    private String roomName;
    private int capacity;
    private List<String> equipment;
    private boolean active;
    private RoomType roomType;

    public Room(String roomId, String roomName, int capacity, RoomType roomType) {
        this.roomId = roomId;
        this.roomName = roomName;
        this.capacity = capacity;
        this.roomType = roomType;
        this.equipment = new ArrayList<>();
        this.active = true;
    }

    public String getRoomId()       { return roomId; }
    public String getRoomName()     { return roomName; }
    public int getCapacity()        { return capacity; }
    public RoomType getRoomType()   { return roomType; }
    public List<String> getEquipment() { return equipment; }
    public boolean isActive()       { return active; }

    public void setActive(boolean active)       { this.active = active; }
    public void setCapacity(int capacity)       { this.capacity = capacity; }
    public void setRoomName(String roomName)    { this.roomName = roomName; }
    public void addEquipment(String item)       { equipment.add(item); }

    @Override
    public String toString() {
        return String.format("Room[%s] %s | Type: %s | Capacity: %d | Equipment: %s | %s",
                roomId, roomName, roomType, capacity, equipment,
                active ? "ACTIVE" : "INACTIVE");
    }
}
