package scms.model;

public enum RoomType {
    LECTURE_HALL,
    SEMINAR_ROOM,
    COMPUTER_LAB,
    MEETING_ROOM,
    SPORTS_HALL
}
