package scms.model;

public enum MaintenanceStatus {
    PENDING,
    ASSIGNED,
    COMPLETED
}
