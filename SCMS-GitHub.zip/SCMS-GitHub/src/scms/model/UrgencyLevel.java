package scms.model;

public enum UrgencyLevel {
    LOW,
    MEDIUM,
    HIGH
}
