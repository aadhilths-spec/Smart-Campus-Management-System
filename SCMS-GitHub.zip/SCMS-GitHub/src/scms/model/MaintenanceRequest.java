package scms.model;

public class MaintenanceRequest {
    private String requestId;
    private String roomId;
    private String reportedByUserId;
    private String description;
    private UrgencyLevel urgency;
    private MaintenanceStatus status;
    private String assignedTo;

    public MaintenanceRequest(String requestId, String roomId, String reportedByUserId,
                               String description, UrgencyLevel urgency) {
        this.requestId = requestId;
        this.roomId = roomId;
        this.reportedByUserId = reportedByUserId;
        this.description = description;
        this.urgency = urgency;
        this.status = MaintenanceStatus.PENDING;
        this.assignedTo = null;
    }

    public String getRequestId()         { return requestId; }
    public String getRoomId()            { return roomId; }
    public String getReportedByUserId()  { return reportedByUserId; }
    public String getDescription()       { return description; }
    public UrgencyLevel getUrgency()     { return urgency; }
    public MaintenanceStatus getStatus() { return status; }
    public String getAssignedTo()        { return assignedTo; }

    public void setStatus(MaintenanceStatus status) { this.status = status; }
    public void setAssignedTo(String assignedTo)    { this.assignedTo = assignedTo; }

    @Override
    public String toString() {
        return String.format("MaintReq[%s] Room: %s | %s | Urgency: %s | Status: %s | Assigned: %s",
                requestId, roomId, description, urgency, status,
                assignedTo != null ? assignedTo : "unassigned");
    }
}
