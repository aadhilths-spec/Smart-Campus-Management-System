package scms.model;

public class Admin extends User {

    public Admin(String userId, String name, String email, String password) {
        super(userId, name, email, password, UserRole.ADMIN);
    }

    @Override
    public String getDashboardInfo() {
        return "Admin Dashboard: Manage rooms, users, and maintenance requests.";
    }
}
