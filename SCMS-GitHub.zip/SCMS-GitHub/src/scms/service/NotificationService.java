package scms.service;

import scms.pattern.Observable;
import scms.pattern.Observer;

import java.util.ArrayList;
import java.util.List;

/**
 * NotificationService — implements Observable (Observer Pattern).
 * Sends notifications to all registered observers when events occur.
 */
public class NotificationService implements Observable {

    private static NotificationService instance; // Singleton
    private List<Observer> observers;
    private List<String> notificationLog;

    private NotificationService() {
        observers = new ArrayList<>();
        notificationLog = new ArrayList<>();
    }

    /** Singleton getInstance — Creational Pattern */
    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    @Override
    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String message) {
        notificationLog.add(message);
        for (Observer o : observers) {
            o.update(message);
        }
    }

    public List<String> getNotificationLog() {
        return new ArrayList<>(notificationLog);
    }

    public void clearLog() {
        notificationLog.clear();
    }
}
