package scms.service;

import scms.exception.UnauthorisedActionException;
import scms.model.*;

import java.util.*;

/**
 * MaintenanceService — handles reporting, assigning, and completing
 * maintenance requests. Fires Observer notifications on every status change.
 */
public class MaintenanceService {

    private Map<String, MaintenanceRequest> requests;
    private NotificationService notificationService;
    private int requestCounter;

    public MaintenanceService(NotificationService notificationService) {
        this.requests = new HashMap<>();
        this.notificationService = notificationService;
        this.requestCounter = 1;
    }

    /**
     * Reports a new maintenance issue.
     */
    public MaintenanceRequest reportIssue(String roomId, String reportedByUserId,
                                           String description, UrgencyLevel urgency) {
        String requestId = "MR" + String.format("%03d", requestCounter++);
        MaintenanceRequest req = new MaintenanceRequest(
                requestId, roomId, reportedByUserId, description, urgency);
        requests.put(requestId, req);

        notificationService.notifyObservers(
                "MAINTENANCE REPORTED [" + urgency + "]: " + description
                        + " in room " + roomId + " (ID: " + requestId + ")");
        return req;
    }

    /**
     * Admin assigns a maintenance request to a technician.
     * Throws UnauthorisedActionException if caller is not an Admin.
     */
    public void assignRequest(String requestId, String technicianName,
                               boolean isAdmin) throws UnauthorisedActionException {
        if (!isAdmin) {
            throw new UnauthorisedActionException(
                    "Only admins can assign maintenance requests.");
        }
        MaintenanceRequest req = requests.get(requestId);
        if (req == null) throw new IllegalArgumentException("Request not found: " + requestId);

        req.setAssignedTo(technicianName);
        req.setStatus(MaintenanceStatus.ASSIGNED);

        notificationService.notifyObservers(
                "MAINTENANCE ASSIGNED: " + requestId + " assigned to " + technicianName);
    }

    /**
     * Marks a maintenance request as completed.
     */
    public void completeRequest(String requestId,
                                 boolean isAdmin) throws UnauthorisedActionException {
        if (!isAdmin) {
            throw new UnauthorisedActionException(
                    "Only admins can mark maintenance as completed.");
        }
        MaintenanceRequest req = requests.get(requestId);
        if (req == null) throw new IllegalArgumentException("Request not found: " + requestId);

        req.setStatus(MaintenanceStatus.COMPLETED);

        notificationService.notifyObservers(
                "MAINTENANCE COMPLETED: " + requestId
                        + " (" + req.getDescription() + ") in room " + req.getRoomId());
    }

    public List<MaintenanceRequest> getAllRequests() {
        return new ArrayList<>(requests.values());
    }

    public List<MaintenanceRequest> getPendingRequests() {
        List<MaintenanceRequest> pending = new ArrayList<>();
        for (MaintenanceRequest r : requests.values()) {
            if (r.getStatus() == MaintenanceStatus.PENDING) pending.add(r);
        }
        return pending;
    }

    public MaintenanceRequest getRequest(String requestId) {
        return requests.get(requestId);
    }

    /** Pre-populates system with sample maintenance requests. */
    public void loadSampleRequests() {
        reportIssue("R001", "U002", "Projector not working",      UrgencyLevel.HIGH);
        reportIssue("R003", "U003", "Three computers won't start", UrgencyLevel.MEDIUM);
        reportIssue("R002", "U002", "Air conditioning broken",     UrgencyLevel.LOW);
    }
}
