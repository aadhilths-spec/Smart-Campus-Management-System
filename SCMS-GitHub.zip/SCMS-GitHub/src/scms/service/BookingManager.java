package scms.service;

import scms.exception.BookingConflictException;
import scms.exception.RoomNotFoundException;
import scms.exception.UnauthorisedActionException;
import scms.model.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

/**
 * BookingManager — manages room bookings, prevents double-booking.
 */
public class BookingManager {

    private Map<String, Booking> bookings;
    private Map<String, Room> rooms;
    private NotificationService notificationService;
    private int bookingCounter;

    public BookingManager(Map<String, Room> rooms, NotificationService notificationService) {
        this.rooms = rooms;
        this.bookings = new HashMap<>();
        this.notificationService = notificationService;
        this.bookingCounter = 1;
    }

    /**
     * Books a room for a user on a given date/time.
     * Throws BookingConflictException if the slot is already taken.
     * Throws RoomNotFoundException if the room does not exist.
     */
    public Booking bookRoom(String roomId, String userId, LocalDate date,
                            LocalTime startTime, LocalTime endTime)
            throws BookingConflictException, RoomNotFoundException {

        Room room = rooms.get(roomId);
        if (room == null) {
            throw new RoomNotFoundException("Room not found: " + roomId);
        }
        if (!room.isActive()) {
            throw new RoomNotFoundException("Room is currently inactive: " + roomId);
        }

        // Check for double-booking
        for (Booking existing : bookings.values()) {
            if (existing.getRoomId().equals(roomId)
                    && existing.overlapsWith(date, startTime, endTime)) {
                throw new BookingConflictException(
                        "Room " + roomId + " is already booked for that time slot.");
            }
        }

        String bookingId = "BK" + String.format("%03d", bookingCounter++);
        Booking booking = new Booking(bookingId, roomId, userId, date, startTime, endTime);
        bookings.put(bookingId, booking);

        notificationService.notifyObservers(
                "Booking CONFIRMED: " + bookingId + " for room " + roomId
                        + " on " + date + " " + startTime + "-" + endTime
                        + " by user " + userId);
        return booking;
    }

    /**
     * Cancels a booking. Only the user who made it (or admin) can cancel.
     */
    public void cancelBooking(String bookingId, String requestingUserId, boolean isAdmin)
            throws UnauthorisedActionException {

        Booking booking = bookings.get(bookingId);
        if (booking == null) {
            throw new IllegalArgumentException("Booking not found: " + bookingId);
        }
        if (!isAdmin && !booking.getUserId().equals(requestingUserId)) {
            throw new UnauthorisedActionException(
                    "User " + requestingUserId + " is not authorised to cancel booking " + bookingId);
        }
        booking.setStatus(BookingStatus.CANCELLED);
        notificationService.notifyObservers(
                "Booking CANCELLED: " + bookingId + " for room " + booking.getRoomId());
    }

    public List<Booking> getAllBookings()              { return new ArrayList<>(bookings.values()); }
    public Booking getBooking(String bookingId)        { return bookings.get(bookingId); }

    public List<Booking> getBookingsForUser(String userId) {
        List<Booking> result = new ArrayList<>();
        for (Booking b : bookings.values()) {
            if (b.getUserId().equals(userId)) result.add(b);
        }
        return result;
    }
}
