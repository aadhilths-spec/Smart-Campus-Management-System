package scms.service;

import scms.exception.DuplicateEntryException;
import scms.model.Room;
import scms.model.RoomType;
import scms.pattern.RoomFactory;

import java.util.*;

/**
 * RoomManager — handles adding, editing, deactivating, and listing rooms.
 */
public class RoomManager {

    private Map<String, Room> rooms;

    public RoomManager() {
        this.rooms = new HashMap<>();
    }

    /**
     * Adds a new room using RoomFactory. Throws DuplicateEntryException
     * if a room with the same ID already exists.
     */
    public Room addRoom(String roomId, String roomName, RoomType type)
            throws DuplicateEntryException {
        if (rooms.containsKey(roomId)) {
            throw new DuplicateEntryException("Room with ID already exists: " + roomId);
        }
        Room room = RoomFactory.createRoom(roomId, roomName, type);
        rooms.put(roomId, room);
        return room;
    }

    /**
     * Edits an existing room's name and capacity.
     */
    public void editRoom(String roomId, String newName, int newCapacity) {
        Room room = rooms.get(roomId);
        if (room == null) throw new IllegalArgumentException("Room not found: " + roomId);
        room.setRoomName(newName);
        room.setCapacity(newCapacity);
    }

    /**
     * Deactivates a room so it cannot be booked.
     */
    public void deactivateRoom(String roomId) {
        Room room = rooms.get(roomId);
        if (room == null) throw new IllegalArgumentException("Room not found: " + roomId);
        room.setActive(false);
    }

    /**
     * Reactivates a previously deactivated room.
     */
    public void activateRoom(String roomId) {
        Room room = rooms.get(roomId);
        if (room == null) throw new IllegalArgumentException("Room not found: " + roomId);
        room.setActive(true);
    }

    public Room getRoom(String roomId)          { return rooms.get(roomId); }
    public Map<String, Room> getAllRooms()       { return Collections.unmodifiableMap(rooms); }

    public List<Room> getActiveRooms() {
        List<Room> active = new ArrayList<>();
        for (Room r : rooms.values()) {
            if (r.isActive()) active.add(r);
        }
        return active;
    }

    /** Pre-populates system with sample rooms using RoomFactory. */
    public void loadSampleRooms() throws DuplicateEntryException {
        addRoom("R001", "Main Lecture Hall A", RoomType.LECTURE_HALL);
        addRoom("R002", "Seminar Room 1",      RoomType.SEMINAR_ROOM);
        addRoom("R003", "Computer Lab B",      RoomType.COMPUTER_LAB);
        addRoom("R004", "Board Meeting Room",  RoomType.MEETING_ROOM);
        addRoom("R005", "Sports Hall",         RoomType.SPORTS_HALL);
    }
}
