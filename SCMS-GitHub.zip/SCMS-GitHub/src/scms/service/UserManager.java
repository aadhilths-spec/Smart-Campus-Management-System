package scms.service;

import scms.exception.DuplicateEntryException;
import scms.model.*;
import scms.pattern.Observer;

import java.util.*;

/**
 * UserManager — manages all users. Each user also acts as an Observer
 * so they receive notifications.
 */
public class UserManager {

    private Map<String, User> users;
    private NotificationService notificationService;

    public UserManager(NotificationService notificationService) {
        this.users = new HashMap<>();
        this.notificationService = notificationService;
    }

    /**
     * Registers a new user and subscribes them to notifications.
     * Throws DuplicateEntryException if the user ID already exists.
     */
    public void registerUser(User user) throws DuplicateEntryException {
        if (users.containsKey(user.getUserId())) {
            throw new DuplicateEntryException("User ID already exists: " + user.getUserId());
        }
        users.put(user.getUserId(), user);

        // Subscribe user as Observer — they receive all notifications
        notificationService.addObserver(new Observer() {
            @Override
            public void update(String message) {
                // In a real system, this would queue the notification per user.
                // Here, the notification log captures all messages centrally.
            }
        });
    }

    /**
     * Authenticates a user by ID and password.
     */
    public User login(String userId, String password) {
        User user = users.get(userId);
        if (user != null && user.getPassword().equals(password)) {
            return user;
        }
        return null;
    }

    public User getUser(String userId)       { return users.get(userId); }
    public Map<String, User> getAllUsers()   { return Collections.unmodifiableMap(users); }

    /** Pre-populates the system with sample users. */
    public void loadSampleUsers() throws DuplicateEntryException {
        registerUser(new Admin("U001", "Alice Admin",   "alice@cardiffmet.ac.uk",  "admin123"));
        registerUser(new StaffMember("U002", "Bob Staff",   "bob@cardiffmet.ac.uk",    "staff123", "Computer Science"));
        registerUser(new StaffMember("U003", "Carol Staff", "carol@cardiffmet.ac.uk",  "staff123", "Engineering"));
        registerUser(new Student("U004",    "Dave Student", "dave@cardiffmet.ac.uk",   "stud123",  "BSc Computing"));
        registerUser(new Student("U005",    "Eva Student",  "eva@cardiffmet.ac.uk",    "stud123",  "BEng Electronics"));
    }
}
