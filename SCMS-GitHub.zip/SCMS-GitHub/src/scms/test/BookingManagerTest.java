package scms.test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import scms.exception.BookingConflictException;
import scms.exception.DuplicateEntryException;
import scms.exception.RoomNotFoundException;
import scms.exception.UnauthorisedActionException;
import scms.model.*;
import scms.service.BookingManager;
import scms.service.NotificationService;
import scms.service.RoomManager;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Unit tests for BookingManager.
 * Tests: successful booking, double-booking prevention,
 *        cancellation, and exception handling.
 */
public class BookingManagerTest {

    private BookingManager bookingManager;
    private RoomManager roomManager;
    private NotificationService notificationService;
    private final LocalDate TODAY = LocalDate.of(2025, 9, 10);

    @Before
    public void setUp() throws DuplicateEntryException {
        notificationService = NotificationService.getInstance();
        notificationService.clearLog();
        roomManager = new RoomManager();
        roomManager.loadSampleRooms();
        bookingManager = new BookingManager(roomManager.getAllRooms(), notificationService);
    }

    // ── Passing tests ─────────────────────────────────────────────────────────

    @Test
    public void testSuccessfulBooking() throws Exception {
        Booking b = bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        assertNotNull("Booking should not be null", b);
        assertEquals("Room ID should match", "R001", b.getRoomId());
        assertEquals("Status should be CONFIRMED", BookingStatus.CONFIRMED, b.getStatus());
    }

    @Test
    public void testNonOverlappingBookingsSameRoom() throws Exception {
        bookingManager.bookRoom("R001", "U002", TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        // Booking directly after the first — should NOT conflict
        Booking b2 = bookingManager.bookRoom("R001", "U003",
                TODAY, LocalTime.of(11, 0), LocalTime.of(13, 0));
        assertNotNull("Second booking should succeed when time slots do not overlap", b2);
    }

    @Test
    public void testBookingDifferentRoomsSameSlot() throws Exception {
        bookingManager.bookRoom("R001", "U002", TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        // Same slot, different room — should be fine
        Booking b2 = bookingManager.bookRoom("R002", "U003",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        assertNotNull("Booking a different room at the same time should succeed", b2);
    }

    @Test
    public void testCancelBookingByOwner() throws Exception {
        Booking b = bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        bookingManager.cancelBooking(b.getBookingId(), "U002", false);
        assertEquals("Status should be CANCELLED", BookingStatus.CANCELLED, b.getStatus());
    }

    @Test
    public void testCancelBookingByAdmin() throws Exception {
        Booking b = bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        // Admin (different user ID) cancels — should be allowed
        bookingManager.cancelBooking(b.getBookingId(), "U001", true);
        assertEquals("Admin should be able to cancel any booking",
                BookingStatus.CANCELLED, b.getStatus());
    }

    @Test
    public void testCancelledSlotBecomesAvailableAgain() throws Exception {
        Booking b1 = bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        bookingManager.cancelBooking(b1.getBookingId(), "U002", false);
        // Same slot should now be available
        Booking b2 = bookingManager.bookRoom("R001", "U003",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        assertNotNull("Cancelled slot should be re-bookable", b2);
    }

    @Test
    public void testNotificationFiredOnBooking() throws Exception {
        bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        assertFalse("Notification log should not be empty after booking",
                notificationService.getNotificationLog().isEmpty());
    }

    // ── Failing tests (expected exceptions) ──────────────────────────────────

    @Test(expected = BookingConflictException.class)
    public void testDoubleBookingThrowsException() throws Exception {
        bookingManager.bookRoom("R001", "U002", TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        // Overlapping slot — must throw BookingConflictException
        bookingManager.bookRoom("R001", "U003", TODAY, LocalTime.of(10, 0), LocalTime.of(12, 0));
    }

    @Test(expected = RoomNotFoundException.class)
    public void testBookingNonExistentRoomThrowsException() throws Exception {
        // Room "R999" does not exist — must throw RoomNotFoundException
        bookingManager.bookRoom("R999", "U002", TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
    }

    @Test(expected = RoomNotFoundException.class)
    public void testBookingInactiveRoomThrowsException() throws Exception {
        roomManager.deactivateRoom("R001");
        // Inactive room — must throw RoomNotFoundException
        bookingManager.bookRoom("R001", "U002", TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
    }

    @Test(expected = UnauthorisedActionException.class)
    public void testCancelOtherUserBookingThrowsException() throws Exception {
        Booking b = bookingManager.bookRoom("R001", "U002",
                TODAY, LocalTime.of(9, 0), LocalTime.of(11, 0));
        // U003 tries to cancel U002's booking without admin rights — must throw
        bookingManager.cancelBooking(b.getBookingId(), "U003", false);
    }
}
