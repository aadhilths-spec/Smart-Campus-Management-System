package scms.test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import scms.pattern.Observer;
import scms.service.NotificationService;

import java.util.ArrayList;
import java.util.List;

/**
 * Unit tests for NotificationService (Observer pattern + Singleton).
 */
public class NotificationServiceTest {

    private NotificationService service;

    @Before
    public void setUp() {
        service = NotificationService.getInstance();
        service.clearLog();
    }

    @Test
    public void testSingletonReturnsSameInstance() {
        NotificationService s1 = NotificationService.getInstance();
        NotificationService s2 = NotificationService.getInstance();
        assertSame("Singleton must return the exact same instance", s1, s2);
    }

    @Test
    public void testObserverReceivesNotification() {
        List<String> received = new ArrayList<>();
        Observer testObserver = message -> received.add(message);
        service.addObserver(testObserver);
        service.notifyObservers("Test message");
        assertTrue("Observer should have received the notification",
                received.contains("Test message"));
        service.removeObserver(testObserver);
    }

    @Test
    public void testNotificationLogStoresMessages() {
        service.notifyObservers("Booking confirmed");
        service.notifyObservers("Maintenance updated");
        assertEquals("Log should contain 2 messages", 2,
                service.getNotificationLog().size());
    }

    @Test
    public void testClearLogEmptiesLog() {
        service.notifyObservers("Hello");
        service.clearLog();
        assertTrue("Log should be empty after clear",
                service.getNotificationLog().isEmpty());
    }

    @Test
    public void testRemovedObserverDoesNotReceive() {
        List<String> received = new ArrayList<>();
        Observer testObserver = message -> received.add(message);
        service.addObserver(testObserver);
        service.removeObserver(testObserver);
        service.notifyObservers("Should not arrive");
        assertTrue("Removed observer should not receive notifications",
                received.isEmpty());
    }
}
