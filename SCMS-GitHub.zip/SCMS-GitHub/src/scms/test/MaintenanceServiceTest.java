package scms.test;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import scms.exception.UnauthorisedActionException;
import scms.model.*;
import scms.service.MaintenanceService;
import scms.service.NotificationService;

/**
 * Unit tests for MaintenanceService.
 * Tests: reporting issues, assigning, completing, and access control.
 */
public class MaintenanceServiceTest {

    private MaintenanceService maintenanceService;
    private NotificationService notificationService;

    @Before
    public void setUp() {
        notificationService = NotificationService.getInstance();
        notificationService.clearLog();
        maintenanceService = new MaintenanceService(notificationService);
    }

    // ── Passing tests ─────────────────────────────────────────────────────────

    @Test
    public void testReportIssueCreatesRequest() {
        MaintenanceRequest req = maintenanceService.reportIssue(
                "R001", "U002", "Projector broken", UrgencyLevel.HIGH);
        assertNotNull("Request should not be null", req);
        assertEquals("Status should start as PENDING", MaintenanceStatus.PENDING, req.getStatus());
        assertEquals("Urgency should be HIGH", UrgencyLevel.HIGH, req.getUrgency());
    }

    @Test
    public void testAssignRequestChangesStatus() throws Exception {
        MaintenanceRequest req = maintenanceService.reportIssue(
                "R001", "U002", "Broken chair", UrgencyLevel.LOW);
        maintenanceService.assignRequest(req.getRequestId(), "Technician John", true);
        assertEquals("Status should be ASSIGNED", MaintenanceStatus.ASSIGNED, req.getStatus());
        assertEquals("Assigned technician should match", "Technician John", req.getAssignedTo());
    }

    @Test
    public void testCompleteRequestChangesStatus() throws Exception {
        MaintenanceRequest req = maintenanceService.reportIssue(
                "R002", "U003", "Leaking pipe", UrgencyLevel.MEDIUM);
        maintenanceService.assignRequest(req.getRequestId(), "Technician Sue", true);
        maintenanceService.completeRequest(req.getRequestId(), true);
        assertEquals("Status should be COMPLETED", MaintenanceStatus.COMPLETED, req.getStatus());
    }

    @Test
    public void testNotificationSentOnIssueReport() {
        maintenanceService.reportIssue("R001", "U002", "Fire alarm test", UrgencyLevel.HIGH);
        assertFalse("Notification log should have an entry after reporting",
                notificationService.getNotificationLog().isEmpty());
    }

    @Test
    public void testGetPendingRequestsReturnsOnlyPending() throws Exception {
        MaintenanceRequest r1 = maintenanceService.reportIssue(
                "R001", "U002", "Issue 1", UrgencyLevel.HIGH);
        maintenanceService.reportIssue("R002", "U003", "Issue 2", UrgencyLevel.LOW);
        // Complete r1
        maintenanceService.assignRequest(r1.getRequestId(), "Tech A", true);
        maintenanceService.completeRequest(r1.getRequestId(), true);

        assertEquals("Only 1 request should remain pending", 1,
                maintenanceService.getPendingRequests().size());
    }

    // ── Failing tests (expected exceptions) ──────────────────────────────────

    /**
     * INTENTIONALLY FAILING TEST — demonstrates robust exception handling.
     * A non-admin user must NOT be able to assign a maintenance request.
     */
    @Test(expected = UnauthorisedActionException.class)
    public void testNonAdminCannotAssignRequest() throws Exception {
        MaintenanceRequest req = maintenanceService.reportIssue(
                "R001", "U004", "Broken window", UrgencyLevel.MEDIUM);
        // isAdmin = false — must throw UnauthorisedActionException
        maintenanceService.assignRequest(req.getRequestId(), "Some Tech", false);
    }

    @Test(expected = UnauthorisedActionException.class)
    public void testNonAdminCannotCompleteRequest() throws Exception {
        MaintenanceRequest req = maintenanceService.reportIssue(
                "R001", "U004", "Broken lock", UrgencyLevel.LOW);
        // isAdmin = false — must throw UnauthorisedActionException
        maintenanceService.completeRequest(req.getRequestId(), false);
    }
}
