package scms.pattern;

/**
 * Observer interface — Behavioural Design Pattern.
 * Any class that wants to receive notifications implements this.
 */
public interface Observer {
    void update(String message);
}
