package scms.pattern;

/**
 * Observable interface — part of Observer pattern.
 * Services that fire notifications implement this.
 */
public interface Observable {
    void addObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers(String message);
}
