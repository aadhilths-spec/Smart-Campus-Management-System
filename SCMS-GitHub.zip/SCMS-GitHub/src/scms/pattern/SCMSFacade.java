package scms.pattern;

import scms.exception.*;
import scms.model.*;
import scms.service.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

/**
 * SCMSFacade — Structural Design Pattern (Facade).
 *
 * Provides a single, simplified entry point to all SCMS subsystems.
 * The console menu only needs to call this class — it never touches
 * individual services directly.
 */
public class SCMSFacade {

    private final RoomManager        roomManager;
    private final BookingManager     bookingManager;
    private final MaintenanceService maintenanceService;
    private final UserManager        userManager;
    private final NotificationService notificationService;

    public SCMSFacade() {
        notificationService = NotificationService.getInstance();
        roomManager         = new RoomManager();
        bookingManager      = new BookingManager(roomManager.getAllRooms(), notificationService);
        maintenanceService  = new MaintenanceService(notificationService);
        userManager         = new UserManager(notificationService);
    }

    // ── Initialisation ────────────────────────────────────────────────────────

    public void loadSampleData() throws DuplicateEntryException {
        userManager.loadSampleUsers();
        roomManager.loadSampleRooms();
        maintenanceService.loadSampleRequests();
    }

    // ── Authentication ────────────────────────────────────────────────────────

    public User login(String userId, String password) {
        return userManager.login(userId, password);
    }

    // ── Room operations ───────────────────────────────────────────────────────

    public Room addRoom(String roomId, String roomName, RoomType type)
            throws DuplicateEntryException {
        return roomManager.addRoom(roomId, roomName, type);
    }

    public void editRoom(String roomId, String newName, int newCapacity) {
        roomManager.editRoom(roomId, newName, newCapacity);
    }

    public void deactivateRoom(String roomId) {
        roomManager.deactivateRoom(roomId);
    }

    public void activateRoom(String roomId) {
        roomManager.activateRoom(roomId);
    }

    public List<Room> getActiveRooms() {
        return roomManager.getActiveRooms();
    }

    public List<Room> getAllRooms() {
        return new java.util.ArrayList<>(roomManager.getAllRooms().values());
    }

    // ── Booking operations ────────────────────────────────────────────────────

    public Booking bookRoom(String roomId, String userId,
                            LocalDate date, LocalTime start, LocalTime end)
            throws BookingConflictException, RoomNotFoundException {
        return bookingManager.bookRoom(roomId, userId, date, start, end);
    }

    public void cancelBooking(String bookingId, String userId, boolean isAdmin)
            throws UnauthorisedActionException {
        bookingManager.cancelBooking(bookingId, userId, isAdmin);
    }

    public List<Booking> getAllBookings() {
        return bookingManager.getAllBookings();
    }

    public List<Booking> getBookingsForUser(String userId) {
        return bookingManager.getBookingsForUser(userId);
    }

    // ── Maintenance operations ────────────────────────────────────────────────

    public MaintenanceRequest reportIssue(String roomId, String userId,
                                           String description, UrgencyLevel urgency) {
        return maintenanceService.reportIssue(roomId, userId, description, urgency);
    }

    public void assignMaintenanceRequest(String requestId, String technician,
                                          boolean isAdmin) throws UnauthorisedActionException {
        maintenanceService.assignRequest(requestId, technician, isAdmin);
    }

    public void completeMaintenanceRequest(String requestId,
                                            boolean isAdmin) throws UnauthorisedActionException {
        maintenanceService.completeRequest(requestId, isAdmin);
    }

    public List<MaintenanceRequest> getAllMaintenanceRequests() {
        return maintenanceService.getAllRequests();
    }

    public List<MaintenanceRequest> getPendingMaintenanceRequests() {
        return maintenanceService.getPendingRequests();
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    public List<String> getNotifications() {
        return notificationService.getNotificationLog();
    }

    // ── User management ───────────────────────────────────────────────────────

    public void registerUser(User user) throws DuplicateEntryException {
        userManager.registerUser(user);
    }

    public List<User> getAllUsers() {
        return new java.util.ArrayList<>(userManager.getAllUsers().values());
    }
}
