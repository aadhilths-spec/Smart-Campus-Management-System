package scms.pattern;

import scms.model.Room;
import scms.model.RoomType;

/**
 * RoomFactory — Creational Design Pattern (Factory Method).
 * Creates pre-configured Room objects based on type.
 */
public class RoomFactory {

    public static Room createRoom(String roomId, String roomName, RoomType type) {
        Room room;
        switch (type) {
            case LECTURE_HALL:
                room = new Room(roomId, roomName, 200, RoomType.LECTURE_HALL);
                room.addEquipment("Projector");
                room.addEquipment("Microphone");
                room.addEquipment("Whiteboard");
                break;
            case SEMINAR_ROOM:
                room = new Room(roomId, roomName, 30, RoomType.SEMINAR_ROOM);
                room.addEquipment("Projector");
                room.addEquipment("Whiteboard");
                break;
            case COMPUTER_LAB:
                room = new Room(roomId, roomName, 40, RoomType.COMPUTER_LAB);
                room.addEquipment("Computers x40");
                room.addEquipment("Projector");
                break;
            case MEETING_ROOM:
                room = new Room(roomId, roomName, 10, RoomType.MEETING_ROOM);
                room.addEquipment("TV Screen");
                room.addEquipment("Video Conferencing");
                break;
            case SPORTS_HALL:
                room = new Room(roomId, roomName, 500, RoomType.SPORTS_HALL);
                room.addEquipment("Sound System");
                break;
            default:
                room = new Room(roomId, roomName, 20, type);
        }
        return room;
    }
}
