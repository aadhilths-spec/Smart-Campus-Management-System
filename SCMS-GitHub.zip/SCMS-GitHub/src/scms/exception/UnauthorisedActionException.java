package scms.exception;

public class UnauthorisedActionException extends Exception {
    public UnauthorisedActionException(String message) {
        super(message);
    }
}
