package scms;

import scms.exception.*;
import scms.model.*;
import scms.pattern.SCMSFacade;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/**
 * SCMSApp — console-based entry point for the Smart Campus Management System.
 *
 * Run this class in NetBeans to start the application.
 * Sample login credentials:
 *   Admin  : U001 / admin123
 *   Staff  : U002 / staff123
 *   Student: U004 / stud123
 */
public class SCMSApp {

    private static final SCMSFacade facade = new SCMSFacade();
    private static final Scanner scanner   = new Scanner(System.in);
    private static User currentUser        = null;

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.println("║  Smart Campus Management System (SCMS)   ║");
        System.out.println("║  Cardiff Metropolitan University          ║");
        System.out.println("╚══════════════════════════════════════════╝");

        try {
            facade.loadSampleData();
            System.out.println("[System] Sample data loaded successfully.\n");
        } catch (DuplicateEntryException e) {
            System.out.println("[Error] " + e.getMessage());
        }

        boolean running = true;
        while (running) {
            if (currentUser == null) {
                running = showLoginMenu();
            } else {
                switch (currentUser.getRole()) {
                    case ADMIN:   showAdminMenu();   break;
                    case STAFF:   showStaffMenu();   break;
                    case STUDENT: showStudentMenu(); break;
                }
            }
        }
        System.out.println("\nGoodbye! SCMS session ended.");
        scanner.close();
    }

    // ── Login ─────────────────────────────────────────────────────────────────

    private static boolean showLoginMenu() {
        System.out.println("┌─────────────────────────────┐");
        System.out.println("│  1. Login                   │");
        System.out.println("│  0. Exit                    │");
        System.out.println("└─────────────────────────────┘");
        System.out.print("Choice: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1":
                System.out.print("User ID  : "); String uid  = scanner.nextLine().trim();
                System.out.print("Password : "); String pass = scanner.nextLine().trim();
                currentUser = facade.login(uid, pass);
                if (currentUser == null) {
                    System.out.println("[!] Invalid credentials. Try again.\n");
                } else {
                    System.out.println("\nWelcome, " + currentUser.getName() + "!");
                    System.out.println(currentUser.getDashboardInfo() + "\n");
                }
                return true;
            case "0":
                return false;
            default:
                System.out.println("[!] Invalid option.\n");
                return true;
        }
    }

    // ── Admin menu ────────────────────────────────────────────────────────────

    private static void showAdminMenu() {
        System.out.println("\n╔═══ ADMIN MENU ═══╗");
        System.out.println("│ 1. View all rooms              │");
        System.out.println("│ 2. Add room                    │");
        System.out.println("│ 3. Deactivate / activate room  │");
        System.out.println("│ 4. View all bookings           │");
        System.out.println("│ 5. View maintenance requests   │");
        System.out.println("│ 6. Assign maintenance request  │");
        System.out.println("│ 7. Complete maintenance request│");
        System.out.println("│ 8. View notifications          │");
        System.out.println("│ 9. View all users              │");
        System.out.println("│ 0. Logout                      │");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Choice: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1": listRooms(false);          break;
            case "2": addRoom();                  break;
            case "3": toggleRoom();               break;
            case "4": listBookings();             break;
            case "5": listMaintenance();          break;
            case "6": assignMaintenance();        break;
            case "7": completeMaintenance();      break;
            case "8": showNotifications();        break;
            case "9": listUsers();                break;
            case "0": logout();                   break;
            default:  System.out.println("[!] Invalid option.");
        }
    }

    // ── Staff menu ────────────────────────────────────────────────────────────

    private static void showStaffMenu() {
        System.out.println("\n╔═══ STAFF MENU ═══╗");
        System.out.println("│ 1. View available rooms        │");
        System.out.println("│ 2. Book a room                 │");
        System.out.println("│ 3. View my bookings            │");
        System.out.println("│ 4. Cancel a booking            │");
        System.out.println("│ 5. Report maintenance issue    │");
        System.out.println("│ 6. View notifications          │");
        System.out.println("│ 0. Logout                      │");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Choice: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1": listRooms(true);            break;
            case "2": bookRoom();                  break;
            case "3": myBookings();                break;
            case "4": cancelBooking();             break;
            case "5": reportMaintenance();         break;
            case "6": showNotifications();         break;
            case "0": logout();                    break;
            default:  System.out.println("[!] Invalid option.");
        }
    }

    // ── Student menu ──────────────────────────────────────────────────────────

    private static void showStudentMenu() {
        System.out.println("\n╔═══ STUDENT MENU ═══╗");
        System.out.println("│ 1. View available rooms        │");
        System.out.println("│ 2. Request a booking           │");
        System.out.println("│ 3. View my bookings            │");
        System.out.println("│ 4. View notifications          │");
        System.out.println("│ 0. Logout                      │");
        System.out.println("╚════════════════════════════════╝");
        System.out.print("Choice: ");
        String choice = scanner.nextLine().trim();

        switch (choice) {
            case "1": listRooms(true);            break;
            case "2": bookRoom();                  break;
            case "3": myBookings();                break;
            case "4": showNotifications();         break;
            case "0": logout();                    break;
            default:  System.out.println("[!] Invalid option.");
        }
    }

    // ── Action methods ────────────────────────────────────────────────────────

    private static void listRooms(boolean activeOnly) {
        List<Room> rooms = activeOnly ? facade.getActiveRooms() : facade.getAllRooms();
        System.out.println("\n--- Rooms ---");
        if (rooms.isEmpty()) { System.out.println("  No rooms found."); return; }
        for (Room r : rooms) System.out.println("  " + r);
    }

    private static void addRoom() {
        System.out.print("Room ID   : "); String id   = scanner.nextLine().trim();
        System.out.print("Room name : "); String name = scanner.nextLine().trim();
        System.out.println("Type (LECTURE_HALL / SEMINAR_ROOM / COMPUTER_LAB / MEETING_ROOM / SPORTS_HALL):");
        System.out.print("Type: ");
        try {
            RoomType type = RoomType.valueOf(scanner.nextLine().trim().toUpperCase());
            Room room = facade.addRoom(id, name, type);
            System.out.println("[OK] Room added: " + room);
        } catch (IllegalArgumentException e) {
            System.out.println("[!] Invalid room type.");
        } catch (DuplicateEntryException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void toggleRoom() {
        System.out.print("Room ID        : "); String id     = scanner.nextLine().trim();
        System.out.print("Activate? (y/n): "); String answer = scanner.nextLine().trim();
        try {
            if (answer.equalsIgnoreCase("y")) {
                facade.activateRoom(id);
                System.out.println("[OK] Room " + id + " activated.");
            } else {
                facade.deactivateRoom(id);
                System.out.println("[OK] Room " + id + " deactivated.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void bookRoom() {
        System.out.print("Room ID    : "); String roomId = scanner.nextLine().trim();
        System.out.print("Date (yyyy-MM-dd): ");
        try {
            LocalDate date  = LocalDate.parse(scanner.nextLine().trim());
            System.out.print("Start time (HH:mm): ");
            LocalTime start = LocalTime.parse(scanner.nextLine().trim());
            System.out.print("End time   (HH:mm): ");
            LocalTime end   = LocalTime.parse(scanner.nextLine().trim());
            Booking booking = facade.bookRoom(roomId, currentUser.getUserId(), date, start, end);
            System.out.println("[OK] " + booking);
        } catch (DateTimeParseException e) {
            System.out.println("[!] Invalid date/time format.");
        } catch (BookingConflictException | RoomNotFoundException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void myBookings() {
        List<Booking> bookings = facade.getBookingsForUser(currentUser.getUserId());
        System.out.println("\n--- My Bookings ---");
        if (bookings.isEmpty()) { System.out.println("  No bookings found."); return; }
        for (Booking b : bookings) System.out.println("  " + b);
    }

    private static void listBookings() {
        List<Booking> bookings = facade.getAllBookings();
        System.out.println("\n--- All Bookings ---");
        if (bookings.isEmpty()) { System.out.println("  No bookings found."); return; }
        for (Booking b : bookings) System.out.println("  " + b);
    }

    private static void cancelBooking() {
        System.out.print("Booking ID: "); String bookingId = scanner.nextLine().trim();
        try {
            boolean isAdmin = currentUser.getRole() == UserRole.ADMIN;
            facade.cancelBooking(bookingId, currentUser.getUserId(), isAdmin);
            System.out.println("[OK] Booking " + bookingId + " cancelled.");
        } catch (UnauthorisedActionException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void reportMaintenance() {
        System.out.print("Room ID     : "); String roomId = scanner.nextLine().trim();
        System.out.print("Description : "); String desc   = scanner.nextLine().trim();
        System.out.println("Urgency (LOW / MEDIUM / HIGH):");
        System.out.print("Urgency: ");
        try {
            UrgencyLevel urgency = UrgencyLevel.valueOf(scanner.nextLine().trim().toUpperCase());
            MaintenanceRequest req = facade.reportIssue(roomId, currentUser.getUserId(), desc, urgency);
            System.out.println("[OK] " + req);
        } catch (IllegalArgumentException e) {
            System.out.println("[!] Invalid urgency level.");
        }
    }

    private static void listMaintenance() {
        List<MaintenanceRequest> reqs = facade.getAllMaintenanceRequests();
        System.out.println("\n--- Maintenance Requests ---");
        if (reqs.isEmpty()) { System.out.println("  No requests found."); return; }
        for (MaintenanceRequest r : reqs) System.out.println("  " + r);
    }

    private static void assignMaintenance() {
        System.out.print("Request ID   : "); String reqId = scanner.nextLine().trim();
        System.out.print("Technician   : "); String tech  = scanner.nextLine().trim();
        try {
            facade.assignMaintenanceRequest(reqId, tech, true);
            System.out.println("[OK] Request " + reqId + " assigned to " + tech);
        } catch (UnauthorisedActionException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void completeMaintenance() {
        System.out.print("Request ID: "); String reqId = scanner.nextLine().trim();
        try {
            facade.completeMaintenanceRequest(reqId, true);
            System.out.println("[OK] Request " + reqId + " marked as COMPLETED.");
        } catch (UnauthorisedActionException e) {
            System.out.println("[!] " + e.getMessage());
        }
    }

    private static void showNotifications() {
        List<String> notes = facade.getNotifications();
        System.out.println("\n--- Notifications (" + notes.size() + ") ---");
        if (notes.isEmpty()) { System.out.println("  No notifications yet."); return; }
        for (int i = 0; i < notes.size(); i++) {
            System.out.println("  [" + (i + 1) + "] " + notes.get(i));
        }
    }

    private static void listUsers() {
        List<User> users = facade.getAllUsers();
        System.out.println("\n--- All Users ---");
        for (User u : users) System.out.println("  " + u);
    }

    private static void logout() {
        System.out.println("[OK] Logged out: " + currentUser.getName() + "\n");
        currentUser = null;
    }
}
